# TRABALHO-N2-NODE.JS
Equipe - Emerson Ponciano, Ingrid Castelo, Luzia Vitoria, Maria Claudiana

Página web para o cadastro, edição e exclusão de livros para uma biblioteca.
Projeto utilizando handlebars para deixar as páginas dinâmicas.
Comunicação da página web com o banco de dados com CRUD (Create, Read, Update, Delete).


https://user-images.githubusercontent.com/42771666/205053467-b1ac1a22-ad7d-49cc-9b79-f605c6fd20ec.mp4

